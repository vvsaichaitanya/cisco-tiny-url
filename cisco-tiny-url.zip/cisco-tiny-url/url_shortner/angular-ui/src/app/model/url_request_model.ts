export class urlRequest {
  url: string;
}