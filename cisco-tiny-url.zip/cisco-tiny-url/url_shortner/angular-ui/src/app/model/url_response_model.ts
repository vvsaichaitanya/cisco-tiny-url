export class urlResponse {
    ID: string;
    URL: string;
}