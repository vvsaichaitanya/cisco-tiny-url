interface urlResponse {
    ID: string;
    URL: string;
}

export class urlResponseObject {
    results: urlResponse[];
}